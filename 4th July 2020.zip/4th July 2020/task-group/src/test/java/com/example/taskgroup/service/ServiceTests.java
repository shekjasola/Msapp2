package com.example.taskgroup.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.example.taskgroup.testutils.JsonUtils;

import com.example.taskgroup.model.Groups;
import com.example.taskgroup.model.Task;

import org.mockito.Mockito;

import com.example.taskgroup.dao.GroupsRepository;

@ExtendWith(SpringExtension.class)
class ServiceTests {

	@TestConfiguration
	static class GroupServiceImplTestContextConfiguration {
		@Bean
		public GroupService groupService() {
			return new GroupServiceImpl();
		}
	}

	@Autowired
	private GroupServiceImpl groupService;

	@MockBean
	private GroupsRepository groupReository;

	@BeforeEach
	public void setup() {

		//Groups group1 = JsonUtils.createGroup((int) 1, "Daily", "Active");
		Task task = new Task();
    	task.setId(1);
    	task.setName("Praveen");
    	task.setPriority("1");
    	task.setStartDate("04-Jul-2020");
    	task.setEndDate("08-Jul-2020");
    	task.setStatus("Active");
    	List<Task> list= new ArrayList<Task>();
    	
    	Groups group = new Groups();
    	group.setId(1);
    	group.setName("Shekhar");
    	group.setStatus("Active");
    	group.setTasks(list);
		System.out.println(group);
		Mockito.when(groupReository.save(group)).thenReturn(group);
	}

	@Test
	public void Test() {
		Groups group1 = JsonUtils.createGroup((int) 1, "Daily", "Active");
		groupService.addGroup(group1);
	}
}
